#include <iostream>
#include <vector>
#include <cmath>
#include <algorithm>
#include <random>
#include <fstream>

using namespace std;

// Constants
const double c = 2e8; // Speed of light in fiber (m/s)
const int Num_onu = 16; // Number of ONUs
const double R_UL_total = 50e9; // Total uplink bandwidth (50Gbps)
const double R_onu_ave = R_UL_total / Num_onu; // Average bandwidth per ONU
const int Len_Packet_byte = 1500; // Packet length (Byte)
const int Len_Packet_bit = Len_Packet_byte * 8; // Packet length (Bit)
const double T_period = 2e-3; // DBA polling period (s)
const int grant_reqst_size = 64 * 8; // Grant request message size (Bit)
const int Num_Packets = 1000; // Number of packets per ONU
const int Num_cycle = 1e5; // Number of polling cycles
const double T_guard = 5e-6; // Guard time for each ONU (s)
const double onu_load = 0.1; // Network load (0-1)
const double avg_pkt_rate = onu_load * R_onu_ave / Len_Packet_bit; // Average packet arrival rate
const double avg_pkt_time = 1.0 / avg_pkt_rate; // Average inter-packet time
const double onu_max_grant = 1e5 * 8; // Maximum grant size per ONU (Bit)

// Generate random packet arrival times following a Pareto distribution
double pareto_distribution(double avg_pkt_time) {
    static random_device rd;
    static mt19937 gen(rd());
    static uniform_real_distribution<> dis(0.0, 1.0);

    double U = dis(gen);
    return avg_pkt_time * pow(-1.0 / log(U), 1.0 / 1.5);
}

int main() {
    // Calculate ONU transmission delay
    vector<double> onu_olt_dist(Num_onu, 20e3); // Distance from ONU to OLT (m)
    vector<double> onu_olt_t(Num_onu);
    for (int i = 0; i < Num_onu; i++)
        onu_olt_t[i] = onu_olt_dist[i] / c;

    // Initialize ONU data rates
    vector<double> R_onu(Num_onu, R_onu_ave);

    // Initialize data structures
    vector<vector<double>> onu_pkt_arr_times(Num_onu, vector<double>(Num_Packets));
    vector<vector<double>> olt_pkt_arr_times(Num_onu, vector<double>(Num_Packets, 0));
    vector<vector<int>> Rest_Packet_index(Num_onu);
    vector<vector<int>> Loss_Packet_index(Num_onu);
    vector<int> transmitted_packet_num(Num_onu, 0);
    vector<vector<int>> transmitted_packet_percycle(Num_cycle, vector<int>(Num_onu, 0));
    vector<double> onu_grant_req(Num_onu, 0);
    vector<vector<double>> req_size(Num_onu, vector<double>(Num_cycle, Len_Packet_bit * 5));

    // Generate packet arrival times for each ONU
    for (int n_onu = 0; n_onu < Num_onu; n_onu++) {
        for (int i = 0; i < Num_Packets; i++) {
            double pkt_arr_time = pareto_distribution(avg_pkt_time);
            onu_pkt_arr_times[n_onu][i] = (i == 0) ? pkt_arr_time : onu_pkt_arr_times[n_onu][i - 1] + pkt_arr_time;
        }
        Rest_Packet_index[n_onu].resize(Num_Packets);
        iota(Rest_Packet_index[n_onu].begin(), Rest_Packet_index[n_onu].end(), 0);
    }

    // Polling DBA process
    vector<double> olt_grant_tx_times(Num_onu, 0);
    for (int n_cycle = 0; n_cycle < Num_cycle; n_cycle++) {
        // Sort ONUs by the number of transmitted packets
        vector<int> index_ONU(Num_onu);
        iota(index_ONU.begin(), index_ONU.end(), 0);
        sort(index_ONU.begin(), index_ONU.end(), [&](int a, int b) {
            return transmitted_packet_num[a] < transmitted_packet_num[b];
            });

        vector<double> olt_grant_rqt_arr_times(Num_onu, 0);
        for (int i = 0; i < Num_onu; i++) {
            int n_onu = index_ONU[i];

            vector<int>& rest_packets = Rest_Packet_index[n_onu];
            vector<int> arrived_packets;
            for (int pkt : rest_packets) {
                if (onu_pkt_arr_times[n_onu][pkt] <= olt_grant_rqt_arr_times[n_onu]) {
                    arrived_packets.push_back(pkt);
                }
            }

            // Determine packets that can be transmitted within the granted bandwidth
            vector<int> transmitted_packets;
            double transmitted_size = 0;
            for (int pkt : arrived_packets) {
                if (transmitted_size + Len_Packet_bit <= req_size[n_onu][n_cycle]) {
                    transmitted_packets.push_back(pkt);
                    transmitted_size += Len_Packet_bit;
                }
                else {
                    break;
                }
            }

            // Transmit packets
            if (!transmitted_packets.empty()) {
                transmitted_packet_num[n_onu] += transmitted_packets.size();
                for (int pkt : transmitted_packets) {
                    olt_pkt_arr_times[n_onu][pkt] = olt_grant_rqt_arr_times[n_onu];
                }
                rest_packets.erase(remove_if(rest_packets.begin(), rest_packets.end(), [&](int p) {
                    return find(transmitted_packets.begin(), transmitted_packets.end(), p) != transmitted_packets.end();
                    }), rest_packets.end());
            }

            // Update OLT grant request arrival time
            if (i == 0)
                olt_grant_rqt_arr_times[n_onu] = olt_grant_tx_times[n_onu] + grant_reqst_size / R_onu[n_onu] + onu_olt_t[n_onu];
            else
                olt_grant_rqt_arr_times[n_onu] = max(olt_grant_tx_times[n_onu] + grant_reqst_size / R_onu[n_onu] + onu_olt_t[n_onu],
                    olt_grant_rqt_arr_times[index_ONU[i - 1]] + T_guard);
        }

        if (accumulate(transmitted_packet_num.begin(), transmitted_packet_num.end(), 0) == Num_Packets * Num_onu)
            break;
    }

    // Compute packet delay for each ONU
    vector<double> delay_per_onu(Num_onu, 0);
    ofstream output("delay_results.csv");
    output << "ONU,Delay (ms)\n";

    for (int n_onu = 0; n_onu < Num_onu; n_onu++) {
        for (int pkt : Rest_Packet_index[n_onu]) {
            delay_per_onu[n_onu] += (olt_pkt_arr_times[n_onu][pkt] - onu_pkt_arr_times[n_onu][pkt]);
        }
        delay_per_onu[n_onu] /= Num_Packets;
        delay_per_onu[n_onu] *= 1e3; // Convert to milliseconds
        output << n_onu + 1 << "," << delay_per_onu[n_onu] << "\n";
        cout << "ONU " << n_onu + 1 << " Delay: " << delay_per_onu[n_onu] << " ms\n";
    }
    output.close();

    return 0;
}
