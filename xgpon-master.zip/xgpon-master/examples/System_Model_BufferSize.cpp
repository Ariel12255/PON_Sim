#include <iostream>
#include <vector>
#include <cmath>
#include <fstream>
#include <numeric>
#include <matplotlibcpp.h> // External library for plotting

namespace plt = matplotlibcpp;

using namespace std;

// Constants
const int CNT = 1; // Number of iterations
const int Num_onu = 16; // Number of ONUs
const double R_UL_total = 50e9; // Total uplink bandwidth (50Gbps)
const double T_period = 2e-3; // DBA polling period (s)

// ONU load values (range from 0.1 to 1.0)
vector<double> onu_load_all = { 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0 };
// Buffer sizes in bits (equivalent to MATLAB 8*[1e4 5e4 1e5])
vector<double> buffer_size_all = { 8e4, 4e5, 8e5 };

// Placeholder function for system model (to be implemented)
void sys_model_buffer_size(double onu_load, double buffer_size, double T_period,
    vector<double>& delay, vector<double>& packet_loss_rate) {
    // Dummy implementation (replace with actual model)
    for (int i = 0; i < Num_onu; i++) {
        delay[i] = (1.0 / onu_load) * (1 + (buffer_size / 8e5)); // Simulated delay
        packet_loss_rate[i] = max(0.0, 0.1 - (buffer_size / 8e5) * 0.05); // Simulated loss rate
    }
}

int main() {
    // Initialize delay and packet loss rate storage
    vector<vector<vector<vector<double>>>> delay(Num_onu, vector<vector<vector<double>>>(onu_load_all.size(), vector<vector<double>>(buffer_size_all.size(), vector<double>(CNT))));
    vector<vector<vector<vector<double>>>> packet_loss_rate(Num_onu, vector<vector<vector<double>>>(onu_load_all.size(), vector<vector<double>>(buffer_size_all.size(), vector<double>(CNT))));

    // Run multiple iterations for averaging
    for (int cnt = 0; cnt < CNT; cnt++) {
        for (size_t n_load = 0; n_load < onu_load_all.size(); n_load++) {
            double onu_load = onu_load_all[n_load];
            for (size_t n_bs = 0; n_bs < buffer_size_all.size(); n_bs++) {
                double buffer_size = buffer_size_all[n_bs];

                // Temporary storage for results per ONU
                vector<double> delay_temp(Num_onu, 0);
                vector<double> packet_loss_temp(Num_onu, 0);

                // Call system model function (replace with actual function)
                sys_model_buffer_size(onu_load, buffer_size, T_period, delay_temp, packet_loss_temp);

                // Store results
                for (int n_onu = 0; n_onu < Num_onu; n_onu++) {
                    delay[n_onu][n_load][n_bs][cnt] = delay_temp[n_onu];
                    packet_loss_rate[n_onu][n_load][n_bs][cnt] = packet_loss_temp[n_onu];
                }
            }
        }
    }

    // Compute final average delay and packet loss rate
    vector<vector<vector<double>>> delay_final(Num_onu, vector<vector<double>>(onu_load_all.size(), vector<double>(buffer_size_all.size(), 0)));
    vector<vector<vector<double>>> packet_loss_rate_final(Num_onu, vector<vector<double>>(onu_load_all.size(), vector<double>(buffer_size_all.size(), 0)));

    for (int n_onu = 0; n_onu < Num_onu; n_onu++) {
        for (size_t n_load = 0; n_load < onu_load_all.size(); n_load++) {
            for (size_t n_bs = 0; n_bs < buffer_size_all.size(); n_bs++) {
                double sum_delay = accumulate(delay[n_onu][n_load][n_bs].begin(), delay[n_onu][n_load][n_bs].end(), 0.0);
                double sum_loss = accumulate(packet_loss_rate[n_onu][n_load][n_bs].begin(), packet_loss_rate[n_onu][n_load][n_bs].end(), 0.0);

                delay_final[n_onu][n_load][n_bs] = sum_delay / CNT;
                packet_loss_rate_final[n_onu][n_load][n_bs] = sum_loss / CNT;
            }
        }
    }

    // Save results to CSV file
    ofstream file("results.csv");
    file << "ONU,Load(Gbps),Buffer Size(bytes),Delay(ms),Packet Loss Rate\n";

    for (int n_onu = 0; n_onu < Num_onu; n_onu++) {
        for (size_t n_load = 0; n_load < onu_load_all.size(); n_load++) {
            double load_gbps = onu_load_all[n_load] * R_UL_total / 1e9;
            for (size_t n_bs = 0; n_bs < buffer_size_all.size(); n_bs++) {
                double buffer_bytes = buffer_size_all[n_bs] / 8;
                file << n_onu + 1 << "," << load_gbps << "," << buffer_bytes << ","
                    << delay_final[n_onu][n_load][n_bs] * 1e3 << "," << packet_loss_rate_final[n_onu][n_load][n_bs] << "\n";
            }
        }
    }
    file.close();

    // Plot results using matplotlibcpp
    for (int n_onu = 0; n_onu < Num_onu; n_onu++) {
        vector<double> x_values, y_values1, y_values2, y_values3;
        vector<double> loss_y1, loss_y2, loss_y3;

        for (size_t n_load = 0; n_load < onu_load_all.size(); n_load++) {
            x_values.push_back(onu_load_all[n_load] * R_UL_total / 1e9);
            y_values1.push_back(delay_final[n_onu][n_load][0] * 1e3);
            y_values2.push_back(delay_final[n_onu][n_load][1] * 1e3);
            y_values3.push_back(delay_final[n_onu][n_load][2] * 1e3);

            loss_y1.push_back(packet_loss_rate_final[n_onu][n_load][0]);
            loss_y2.push_back(packet_loss_rate_final[n_onu][n_load][1]);
            loss_y3.push_back(packet_loss_rate_final[n_onu][n_load][2]);
        }

        // Delay plot
        plt::figure();
        plt::plot(x_values, y_values1, "-*");
        plt::plot(x_values, y_values2, "-o");
        plt::plot(x_values, y_values3, "-^");
        plt::grid(true);
        plt::xlabel("Load (Gbps)");
        plt::ylabel("Delay (ms)");
        plt::title("ONU " + to_string(n_onu + 1) + ", Period = " + to_string(T_period * 1e3) + " ms");
        plt::legend({ "Buffer size = " + to_string((int)buffer_size_all[0] / 8) + " bytes",
                     "Buffer size = " + to_string((int)buffer_size_all[1] / 8) + " bytes",
                     "Buffer size = " + to_string((int)buffer_size_all[2] / 8) + " bytes" });
        plt::show();

        // Packet loss plot
        plt::figure();
        plt::plot(x_values, loss_y1, "-*");
        plt::plot(x_values, loss_y2, "-o");
        plt::plot(x_values, loss_y3, "-^");
        plt::grid(true);
        plt::xlabel("Load (Gbps)");
        plt::ylabel("Packet Loss Rate");
        plt::title("ONU " + to_string(n_onu + 1) + ", Period = " + to_string(T_period * 1e3) + " ms");
        plt::legend({ "Buffer size = " + to_string((int)buffer_size_all[0] / 8) + " bytes",
                     "Buffer size = " + to_string((int)buffer_size_all[1] / 8) + " bytes",
                     "Buffer size = " + to_string((int)buffer_size_all[2] / 8) + " bytes" });
        plt::show();
    }

    return 0;
}
