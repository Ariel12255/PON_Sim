#include <iostream>
#include <vector>
#include <cmath>
#include <algorithm>
#include <random>
#include <numeric>

using namespace std;

// Parameters
double c = 2e8; // Speed of light in fiber (m/s)
int Num_onu = 16; // Number of ONUs
vector<double> onu_olt_dist(Num_onu, 20000); // OLT-ONU distance (m)
vector<double> onu_olt_t(Num_onu); // OLT-ONU propagation delay (s)
for (int i = 0; i < Num_onu; i++) {
    onu_olt_t[i] = onu_olt_dist[i] / c;
}
double R_UL_total = 50e9; // UL total data rate
double R_onu_ave = R_UL_total / Num_onu;
double min_R_onu = 1e9;
double max_R_onu = 20e9;
vector<double> R_onu(Num_onu, R_onu_ave); // Data rate of each ONU
int packet_fix_flag = 1; // 1: fixed packet size, 0: random packet size
int Len_Packet_byte_max = 1500; // Maximum packet length (Byte)
int Len_Packet_byte_min = 100;  // Minimum packet length (Byte)
// double T_period = 2e-3; // Period time (s)
int grant_reqst_size = 64 * 8; // Grant or request message size (Bit)
// double buffer_size = 1e5 * 8; // Buffer size for ONU (Bit)
double onu_max_grant = buffer_size; // ONU maximum grant size (Bit)
double T_guard = 5e-6; // Guard time for each ONU (s)
int Num_Packets = 1000; // Number of packets
vector<double> SNR_onu(Num_onu, 30); // Signal-to-Noise Ratio for each ONU
int SNR_thre = 20; // SNR threshold
int Num_cycle = 100000; // Number of polling cycles
```

int main() {
    //Different ONU Load 
    int main() {
        // Define different loads for each ONU (some high-demand, some low-demand)
        vector<double> onu_load = { 0.1 1.0 };
    
    // Different ONU Buffer Size
    vector<double> buffer_size_per_onu = { 1e4 * 8,  1e5 * 4, 1e5 * 8 };

    vector<double> onu_olt_dist(Num_onu, 20e3);
    vector<double> onu_olt_t(Num_onu);
    for (int i = 0; i < Num_onu; i++)
        onu_olt_t[i] = onu_olt_dist[i] / c;

    vector<double> R_onu(Num_onu, R_UL_total / Num_onu);
    vector<vector<double>> onu_pkt_arr_times(Num_onu, vector<double>(Num_Packets));
    vector<vector<double>> olt_pkt_arr_times(Num_onu, vector<double>(Num_Packets, 0));
    vector<vector<int>> Rest_Packet_index(Num_onu);
    vector<vector<int>> Loss_Packet_index(Num_onu);

//packet arrival times
for n_onu = 1:Num_onu
if packet_fix_flag == 1
Len_Packet_all_onu(n_onu, :) = Len_Packet_byte_max * 8 * ones(1, Num_Packets);//all packets length for all ONUs
avg_pkt_rate = onu_load * R_onu_ave / Len_Packet_byte_max / 8;// average packet arrival rate
else
Len_Packet_all_onu(n_onu, :) = randi([Len_Packet_byte_min Len_Packet_byte_max], 1, Num_Packets) * 8;// all packets length for all ONUs
avg_pkt_rate = onu_load * R_onu_ave / (Len_Packet_byte_max + Len_Packet_byte_min) * 2 / 8;// average packet arrival rate
end
avg_pkt_time = 1 / avg_pkt_rate; // average packet duration
U = rand(Num_Packets, 1);
pkt_arr_time = avg_pkt_time * (-1. / log(U)). ^ (1. / 1.5);//Pareto
onu_pkt_arr_times(n_onu, :) = cumsum(pkt_arr_time);//cumulatively add packet inter - arrival times
Rest_Packet_index{ n_onu } = [1:Num_Packets];// untransmitted packet index
Loss_Packet_index{ n_onu } = [];//loss packet index
end
olt_pkt_arr_times = zeros(Num_onu, Num_Packets);
transmitted_packet_num = zeros(1, Num_onu);//initialization
onu_grant_req = zeros(1, Num_onu);// initialize all ONUs with zero grant
req_size = ones(Num_onu, Num_cycle) // Len_Packet_byte_max * 8 * 5;
transmitted_packet_percycle = zeros(Num_cycle, Num_onu);

//polling cycle
tx_packet_index_before = cell(1, Num_onu);
olt_grant_tx_times = zeros(1, Num_onu);// times to send grants from OLTs
for n_cycle = 1:Num_cycle
tx_packet_index_before = cell(1, Num_onu);
[~, index_ONU] = sort(transmitted_packet_num);% sorting ONUs by tranmitted packet number
if n_cycle >= 2
olt_grant_tx_times = (max(olt_grant_rqt_arr_times) + T_guard) * ones(1, Num_onu);// times to send grants from OLTs
end
onu_grant_arr_times = zeros(1, Num_onu);% times when ONUs receive grant messages
for n = 1:Num_onu
n_onu = index_ONU(n);
onu_grant_arr_times(n_onu) = olt_grant_tx_times(n_onu) + onu_olt_t(n_onu);
// received packet
index_p1 = find(onu_pkt_arr_times(n_onu, Rest_Packet_index{ n_onu }) <= onu_grant_arr_times(n_onu));% arrived packets
Pakect_size1 = Len_Packet_all_onu(n_onu, index_p1);
Pakect_size_sum1 = cumsum(Pakect_size1);
//if Pakect_size_sum1(end) > buffer_size
// keyboard
// end
if sum(Pakect_size1) > buffer_size
numpacket_in_buffer = find(cumsum(flip(Pakect_size1)) <= buffer_size, 1, 'last');
index_out_buffer = [1:length(Pakect_size1) - numpacket_in_buffer];
loss_packet_ind = Rest_Packet_index{ n_onu }(index_out_buffer);
Loss_Packet_index{ n_onu } = [Loss_Packet_index{ n_onu } loss_packet_ind];
Rest_Packet_index{ n_onu }(index_out_buffer) = [];
index_p1 = find(onu_pkt_arr_times(n_onu, Rest_Packet_index{ n_onu }) <= onu_grant_arr_times(n_onu));% arrived packets
Pakect_size1 = Len_Packet_all_onu(n_onu, index_p1);
Pakect_size_sum1 = cumsum(Pakect_size1);
end
if ~isempty(Pakect_size_sum1)
temp_tran_i = find(Pakect_size_sum1 <= req_size(n_onu, n_cycle), 1, 'last');
trans_packet_ind = Rest_Packet_index{ n_onu }(1:temp_tran_i);
transmitted_packet_num(n_onu) = transmitted_packet_num(n_onu) + temp_tran_i;
Rest_Packet_index{ n_onu }(1:temp_tran_i) = [];
transmitted_packet_percycle(n_cycle, n_onu) = temp_tran_i;
real_trans_packet(n_onu) = Pakect_size_sum1(temp_tran_i);
else
real_trans_packet(n_onu) = 0;
end
//
// request size from ONU
index_p2 = find(onu_pkt_arr_times(n_onu, Rest_Packet_index{ n_onu }) <= onu_grant_arr_times(n_onu) + 2 * onu_olt_t(n));% arrived packets
Pakect_size2 = Len_Packet_all_onu(n_onu, index_p2);
Pakect_size_sum2 = cumsum(Pakect_size2);
if ~isempty(Pakect_size_sum2)
temp_i = find(Pakect_size_sum2 <= onu_max_grant, 1, 'last');
req_size(n_onu, n_cycle + 1) = Pakect_size_sum2(temp_i);
end

ONU_request_size(n_onu) = grant_reqst_size + real_trans_packet(n_onu);
temp_R = req_size(n_onu, n_cycle) / sum(req_size(:, n_cycle), 1) * R_UL_total;
R_onu(n_onu) = min(max(min_R_onu, temp_R), max_R_onu);

// request information arrival time in olt
if n == 1
olt_grant_rqt_arr_times(n_onu) = onu_grant_arr_times(n_onu) + ONU_request_size(n_onu) / R_onu(n_onu) + onu_olt_t(n_onu);
else
olt_grant_rqt_arr_times(n_onu) = max(onu_grant_arr_times(n_onu) + ONU_request_size(n_onu) / R_onu(n_onu) + onu_olt_t(n_onu), ...
    olt_grant_rqt_arr_times(index_ONU(n - 1)) + T_guard);
end

if ~isempty(Pakect_size_sum1) && SNR_onu(n_onu) >= SNR_thre


//update packet and arrival time in olt
olt_pkt_arr_times(n_onu, trans_packet_ind) = olt_grant_rqt_arr_times(n_onu);
end

Num_period = ceil((olt_grant_tx_times(n_onu) + eps) / T_period);// can't out of period
if olt_grant_rqt_arr_times(n_onu) > Num_period* T_period
break
end
end

if sum(transmitted_packet_num) == Num_Packets * Num_onu
break
end
for n = 1:Num_onu
real_rate(n, n_cycle) = sum(Len_Packet_all_onu(n, 1:sum(transmitted_packet_percycle(:, n), 1)), 2). / (olt_grant_rqt_arr_times(n) - onu_olt_t(n) * 2 * n_cycle);
end

end
//
// 
// delay
packet_dalay = olt_pkt_arr_times - onu_pkt_arr_times;

// average delay / data rate
for n_onu = 1:Num_onu
olt_pkt_arr_times_temp = olt_pkt_arr_times(n_onu, :);
onu_pkt_arr_times_temp = onu_pkt_arr_times(n_onu, :);
Len_Packet_all_onu_temp = Len_Packet_all_onu(n_onu, :);
packet_dalay_temp = packet_dalay(n_onu, :);
max_pkt = ceil(max(olt_pkt_arr_times_temp) / T_period);
mean_packet_dalay = zeros(1, max_pkt);
mean_packet_rate = zeros(1, max_pkt);
for n_pkt = 1:max_pkt
ind_pkt = find(olt_pkt_arr_times_temp >= (n_pkt - 1) * T_period & olt_pkt_arr_times_temp < n_pkt * T_period & olt_pkt_arr_times_temp ~= 0);
if ~isempty(ind_pkt)
mean_packet_dalay(n_pkt) = mean(packet_dalay_temp(ind_pkt));
mean_packet_rate(n_pkt) = mean(sum(Len_Packet_all_onu_temp(1:ind_pkt(end))) / onu_pkt_arr_times_temp(ind_pkt(end)));
else
mean_packet_dalay(n_pkt) = mean_packet_dalay(n_pkt - 1);
mean_packet_rate(n_pkt) = mean_packet_rate(n_pkt - 1);
end
end

delay_per_onu(n_onu) = mean(mean_packet_dalay);
packet_loss_rate_per_onu(n_onu) = length(Loss_Packet_index{ n_onu }) / Num_Packets;
end
